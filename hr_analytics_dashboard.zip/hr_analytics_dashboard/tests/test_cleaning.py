import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils.analysis import rate_by
from utils.cleaning import load_clean


def test_cleaning_invariants():
    df, log = load_clean()
    assert df["EmpID"].is_unique
    assert df.isna().sum().sum() == 0
    assert "TravelRarely" not in set(df["BusinessTravel"])
    assert not {"EmployeeCount", "StandardHours", "Over18"} & set(df.columns)
    assert (df["YearsWithCurrManager"] <= df["YearsAtCompany"]).all()
    assert (df["YearsInCurrentRole"] <= df["YearsAtCompany"]).all()
    assert set(df["Attrition"]) == {"Yes", "No"}
    assert len(log) > 0


def test_rate_by_keeps_all_rows():
    df, _ = load_clean()
    r = rate_by(df, "Department")
    assert r["Employees"].sum() == len(df)
    assert r["Left"].sum() == df["AttritionFlag"].sum()
