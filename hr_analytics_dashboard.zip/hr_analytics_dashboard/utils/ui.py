"""Theme, CSS, KPI cards and Streamlit-version-safe display helpers."""
from __future__ import annotations

import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

STAY = "#2A9D8F"   # teal  - employees who stayed
LEFT = "#E76F51"   # coral - employees who left
PRIMARY = "#264653"
ACCENT = "#E9C46A"
SEQ = ["#264653", "#2A9D8F", "#8AB17D", "#E9C46A", "#F4A261", "#E76F51", "#9B5DE5", "#4D9DE0"]
ATTR_COLORS = {"No": STAY, "Yes": LEFT}

pio.templates["hr"] = go.layout.Template(
    layout=dict(
        font=dict(family="Inter, Segoe UI, sans-serif", size=13, color="#2b2d42"),
        colorway=SEQ,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        title=dict(font=dict(size=16, color=PRIMARY), x=0.0, xanchor="left"),
        margin=dict(l=10, r=10, t=55, b=10),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, title_text=""),
        xaxis=dict(gridcolor="rgba(120,120,120,.15)", zeroline=False),
        yaxis=dict(gridcolor="rgba(120,120,120,.15)", zeroline=False),
        hoverlabel=dict(font_size=13),
    )
)
pio.templates.default = "plotly_white+hr"

CSS = """
<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem; max-width: 1400px;}
.hero {background: linear-gradient(120deg,#264653 0%,#2A9D8F 100%); padding: 1.6rem 2rem; border-radius: 18px;
       color: #fff; margin-bottom: 1.2rem; box-shadow: 0 8px 24px rgba(38,70,83,.25);}
.hero h1 {margin: 0; font-size: 2rem; color:#fff;} .hero p {margin: .3rem 0 0; opacity:.9; font-size: 1rem;}
.kpi {background:#fff; border-radius:16px; padding:1rem 1.2rem; border-left:6px solid var(--c,#2A9D8F);
      box-shadow:0 2px 12px rgba(0,0,0,.07); height:100%;}
.kpi .lbl {font-size:.78rem; text-transform:uppercase; letter-spacing:.06em; color:#6c757d; font-weight:600;}
.kpi .val {font-size:1.85rem; font-weight:700; color:#264653; line-height:1.25;}
.kpi .sub {font-size:.8rem; color:#6c757d;}
.insight {background:#f4faf9; border:1px solid #cfe8e4; border-left:5px solid #2A9D8F; border-radius:12px;
          padding:.7rem 1rem; margin-bottom:.6rem; color:#264653; font-size:.95rem;}
.insight.warn {background:#fff6f3; border-color:#f6d3c9; border-left-color:#E76F51;}
h2, h3 {color:#264653;}
button[data-baseweb="tab"] {font-weight:600;}
section[data-testid="stSidebar"] {background:#f1f6f6;}
</style>
"""


def inject_css() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def hero(title: str, subtitle: str) -> None:
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def kpi(col, label: str, value: str, sub: str = "", color: str = STAY) -> None:
    col.markdown(
        f'<div class="kpi" style="--c:{color}"><div class="lbl">{label}</div>'
        f'<div class="val">{value}</div><div class="sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def insight(text: str, warn: bool = False) -> None:
    st.markdown(f'<div class="insight{" warn" if warn else ""}">{text}</div>', unsafe_allow_html=True)


def show(fig: go.Figure, height: int | None = None, key: str | None = None) -> None:
    """Render a Plotly figure full-width (works on old and new Streamlit)."""
    if height:
        fig.update_layout(height=height)
    try:
        st.plotly_chart(fig, width="stretch", key=key)
    except TypeError:
        st.plotly_chart(fig, use_container_width=True, key=key)


def show_df(df, **kwargs) -> None:
    try:
        st.dataframe(df, width="stretch", **kwargs)
    except TypeError:
        st.dataframe(df, use_container_width=True, **kwargs)
