"""Data loading & cleaning for the HR Analytics dataset.

Every step is logged so the dashboard can show a transparent cleaning report.
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
RAW_FILE = DATA_DIR / "HR_Analytics.xlsx"
CLEAN_FILE = DATA_DIR / "HR_Analytics_cleaned.csv"
RAW_SHEET = "HR_Analytics"  # Detail1 / Sheet1 are leftover pivot-table artefacts

LIKERT_4 = {1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
EDUCATION = {1: "Below College", 2: "College", 3: "Bachelor", 4: "Master", 5: "Doctor"}
WLB = {1: "Bad", 2: "Good", 3: "Better", 4: "Best"}
PERFORMANCE = {1: "Low", 2: "Good", 3: "Excellent", 4: "Outstanding"}
STOCK = {0: "None", 1: "Level 1", 2: "Level 2", 3: "Level 3"}

AGE_ORDER = ["18-25", "26-35", "36-45", "46-55", "55+"]
SLAB_ORDER = ["Upto 5k", "5k-10k", "10k-15k", "15k+"]
TENURE_ORDER = ["0-1 yrs", "2-5 yrs", "6-10 yrs", "11-20 yrs", "20+ yrs"]
DISTANCE_ORDER = ["1-5 km", "6-10 km", "11-20 km", "20+ km"]


def load_raw(path: Path | str = RAW_FILE) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name=RAW_SHEET)


def clean(df_raw: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """Return (clean_df, log). log = list of {Step, Issue found, Action taken, Rows / cells affected}."""
    log: list[dict] = []

    def note(step, issue, action, n):
        log.append({"Step": step, "Issue found": issue, "Action taken": action, "Rows / cells affected": int(n)})

    df = df_raw.copy()
    n0 = len(df)

    # 1. whitespace / text hygiene
    changed = 0
    for c in df.columns:
        if df[c].dtype == object or str(df[c].dtype) in ("str", "string"):
            s = df[c].astype("string")
            stripped = s.str.strip()
            changed += int((stripped != s).sum())
            df[c] = stripped.astype(object)
    note("Text hygiene", "Leading/trailing whitespace in text columns", "Stripped whitespace", changed)

    # 2. inconsistent category spelling
    typo = df["BusinessTravel"].eq("TravelRarely")
    df.loc[typo, "BusinessTravel"] = "Travel_Rarely"
    note("Category standardisation", "BusinessTravel has both TravelRarely and Travel_Rarely",
         "Merged into Travel_Rarely", typo.sum())

    # 3. duplicates
    exact = df.duplicated().sum()
    df = df.drop_duplicates().reset_index(drop=True)
    note("Duplicates", "Fully identical duplicate rows", "Removed (kept first)", exact)

    id_dups = df["EmpID"].duplicated().sum()
    df = df.drop_duplicates(subset="EmpID", keep="first").reset_index(drop=True)
    note("Duplicates", "Same EmpID repeated, differing only in YearsWithCurrManager",
         "Kept first occurrence per EmpID", id_dups)

    # 4. constant columns
    const = [c for c in df.columns if df[c].nunique(dropna=False) == 1]
    df = df.drop(columns=const)
    note("Column pruning", "Constant columns with no analytical value: " + ", ".join(const),
         "Dropped columns", len(const))

    # 5. missing values
    miss = df["YearsWithCurrManager"].isna()
    df["ManagerYearsImputed"] = miss
    med = df.groupby("JobRole")["YearsWithCurrManager"].transform("median")
    df["YearsWithCurrManager"] = df["YearsWithCurrManager"].fillna(med).fillna(df["YearsWithCurrManager"].median())
    df["YearsWithCurrManager"] = df["YearsWithCurrManager"].round().astype(int)
    # an imputed value can never exceed the employee's company tenure
    df.loc[miss, "YearsWithCurrManager"] = df.loc[miss, ["YearsWithCurrManager", "YearsAtCompany"]].min(axis=1)
    note("Missing values", "YearsWithCurrManager is blank",
         "Imputed with JobRole median, capped at YearsAtCompany; flagged in ManagerYearsImputed", miss.sum())

    # 6. logical validation (flag, do not delete)
    bad = ((df["YearsAtCompany"] > df["TotalWorkingYears"]) | (df["YearsInCurrentRole"] > df["YearsAtCompany"])
           | (df["YearsWithCurrManager"] > df["YearsAtCompany"]) | (df["Age"] < 18))
    note("Validation", "Tenure inconsistencies (role/manager years > company years, company > career, age < 18)",
         "None found" if bad.sum() == 0 else "Flagged only (kept)", bad.sum())

    # 7. feature engineering
    df["AttritionFlag"] = (df["Attrition"] == "Yes").astype(int)
    df["EducationLevel"] = df["Education"].map(EDUCATION)
    for col in ["EnvironmentSatisfaction", "JobSatisfaction", "RelationshipSatisfaction", "JobInvolvement"]:
        df[col + "Label"] = df[col].map(LIKERT_4)
    df["WorkLifeBalanceLabel"] = df["WorkLifeBalance"].map(WLB)
    df["PerformanceLabel"] = df["PerformanceRating"].map(PERFORMANCE)
    df["StockOptionLabel"] = df["StockOptionLevel"].map(STOCK)
    df["TenureBand"] = pd.cut(df["YearsAtCompany"], [-1, 1, 5, 10, 20, 100], labels=TENURE_ORDER).astype(str)
    df["DistanceBand"] = pd.cut(df["DistanceFromHome"], [0, 5, 10, 20, 100], labels=DISTANCE_ORDER).astype(str)
    df["AvgSatisfaction"] = df[["EnvironmentSatisfaction", "JobSatisfaction",
                                "RelationshipSatisfaction", "WorkLifeBalance"]].mean(axis=1).round(2)
    df["IncomePerYearOfExp"] = (df["MonthlyIncome"] / df["TotalWorkingYears"].clip(lower=1)).round(0)
    note("Feature engineering", "Numeric codes are hard to read",
         "Added readable labels, TenureBand, DistanceBand, AvgSatisfaction, AttritionFlag, IncomePerYearOfExp",
         len(df))

    note("Summary", f"{n0:,} raw rows", f"{len(df):,} clean rows", n0 - len(df))
    return df, log


def load_clean() -> tuple[pd.DataFrame, list[dict]]:
    return clean(load_raw())


if __name__ == "__main__":
    out, lg = load_clean()
    out.to_csv(CLEAN_FILE, index=False)
    pd.set_option("display.width", 250, "display.max_colwidth", 90)
    print(pd.DataFrame(lg).to_string(index=False))
    print(f"\nSaved {len(out):,} rows x {out.shape[1]} cols -> {CLEAN_FILE}")
