"""Pure-pandas analysis helpers (no Streamlit/Plotly) so they can be unit-tested."""
from __future__ import annotations

import pandas as pd

CATEGORICAL_DIMS = {
    "Department": "Department", "Job Role": "JobRole", "Gender": "Gender", "Age Group": "AgeGroup",
    "Marital Status": "MaritalStatus", "Business Travel": "BusinessTravel", "Over Time": "OverTime",
    "Education Field": "EducationField", "Education Level": "EducationLevel", "Salary Slab": "SalarySlab",
    "Tenure Band": "TenureBand", "Distance From Home": "DistanceBand", "Stock Option": "StockOptionLabel",
    "Job Level": "JobLevel", "Job Satisfaction": "JobSatisfactionLabel",
    "Environment Satisfaction": "EnvironmentSatisfactionLabel", "Work-Life Balance": "WorkLifeBalanceLabel",
    "Job Involvement": "JobInvolvementLabel", "Companies Worked": "NumCompaniesWorked",
}

NUMERIC_COLS = ["Age", "DailyRate", "DistanceFromHome", "Education", "EnvironmentSatisfaction", "HourlyRate",
                "JobInvolvement", "JobLevel", "JobSatisfaction", "MonthlyIncome", "MonthlyRate",
                "NumCompaniesWorked", "PercentSalaryHike", "PerformanceRating", "RelationshipSatisfaction",
                "StockOptionLevel", "TotalWorkingYears", "TrainingTimesLastYear", "WorkLifeBalance",
                "YearsAtCompany", "YearsInCurrentRole", "YearsSinceLastPromotion", "YearsWithCurrManager"]


def rate_by(df: pd.DataFrame, col: str, order: list | None = None, min_n: int = 1) -> pd.DataFrame:
    """Headcount, leavers and attrition rate (%) by a category column."""
    g = df.groupby(col, observed=True)["AttritionFlag"].agg(Employees="count", Left="sum").reset_index()
    g["Attrition %"] = (g["Left"] / g["Employees"] * 100).round(1)
    g = g[g["Employees"] >= min_n]
    if order:
        g[col] = pd.Categorical(g[col], categories=order, ordered=True)
        g = g.sort_values(col)
    else:
        g = g.sort_values("Attrition %", ascending=False)
    g[col] = g[col].astype(str)
    return g.reset_index(drop=True)


def overall_rate(df: pd.DataFrame) -> float:
    return float(df["AttritionFlag"].mean() * 100) if len(df) else 0.0


def build_insights(df: pd.DataFrame) -> list[tuple[str, bool]]:
    """Auto-generated, data-driven talking points -> list of (text, is_warning)."""
    out: list[tuple[str, bool]] = []
    if len(df) < 30 or df["AttritionFlag"].sum() == 0:
        return [("Not enough data under the current filters to generate insights.", False)]
    base = overall_rate(df)

    ot = rate_by(df, "OverTime").set_index("OverTime")["Attrition %"]
    if {"Yes", "No"} <= set(ot.index) and ot["No"] > 0:
        out.append((f"<b>Overtime is strongly associated with exits:</b> {ot['Yes']:.1f}% of employees working overtime leave, "
                    f"vs {ot['No']:.1f}% without ({ot['Yes'] / ot['No']:.1f}x higher).", True))

    jr = rate_by(df, "JobRole", min_n=20)
    if len(jr):
        r = jr.iloc[0]
        out.append((f"<b>Highest-risk role:</b> {r['JobRole']} at {r['Attrition %']:.1f}% attrition "
                    f"({int(r['Left'])} of {int(r['Employees'])}).", True))

    ms = rate_by(df, "MaritalStatus", min_n=20)
    if len(ms):
        r = ms.iloc[0]
        out.append((f"<b>Marital status:</b> {r['MaritalStatus']} employees leave most often ({r['Attrition %']:.1f}%).", False))

    ten = rate_by(df, "TenureBand", order=["0-1 yrs", "2-5 yrs", "6-10 yrs", "11-20 yrs", "20+ yrs"], min_n=20)
    if len(ten):
        r = ten.sort_values("Attrition %", ascending=False).iloc[0]
        out.append((f"<b>Early-tenure risk:</b> {r['TenureBand']} tenure shows the highest attrition ({r['Attrition %']:.1f}%).", True))

    sl = rate_by(df, "SalarySlab", order=["Upto 5k", "5k-10k", "10k-15k", "15k+"], min_n=20)
    if len(sl) >= 2:
        out.append((f"<b>Pay slab:</b> the {sl.iloc[0]['SalarySlab']} slab loses {sl.iloc[0]['Attrition %']:.1f}% "
                    f"vs {sl.iloc[-1]['Attrition %']:.1f}% in {sl.iloc[-1]['SalarySlab']}.", False))

    inc = df.groupby("Attrition")["MonthlyIncome"].median()
    if {"Yes", "No"} <= set(inc.index):
        out.append((f"<b>Income gap:</b> median income of leavers is ${inc['Yes']:,.0f} vs ${inc['No']:,.0f} for stayers.", False))

    ag = rate_by(df, "AgeGroup", order=["18-25", "26-35", "36-45", "46-55", "55+"], min_n=20)
    if len(ag):
        r = ag.sort_values("Attrition %", ascending=False).iloc[0]
        out.append((f"<b>Age:</b> the {r['AgeGroup']} group has the highest attrition ({r['Attrition %']:.1f}% vs {base:.1f}% overall).", False))
    return out


def correlations(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    return df[cols].corr(numeric_only=True).round(2)


def attrition_correlations(df: pd.DataFrame) -> pd.Series:
    cols = [c for c in NUMERIC_COLS if c in df.columns]
    return df[cols].corrwith(df["AttritionFlag"]).dropna().sort_values().round(3)
