"""HR Analytics - interactive Streamlit dashboard.

Run:  streamlit run app.py
"""
from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from utils.analysis import (CATEGORICAL_DIMS, NUMERIC_COLS, attrition_correlations, build_insights,
                            correlations, overall_rate, rate_by)
from utils.cleaning import (AGE_ORDER, DISTANCE_ORDER, SLAB_ORDER, TENURE_ORDER, load_clean)
from utils.ui import (ATTR_COLORS, ACCENT, LEFT, PRIMARY, STAY, hero, inject_css, insight, kpi, show, show_df)

st.set_page_config(page_title="HR Analytics Dashboard", page_icon="👥", layout="wide")
inject_css()

LIKERT = ["Low", "Medium", "High", "Very High"]
WLB_ORDER = ["Bad", "Good", "Better", "Best"]
EDU_ORDER = ["Below College", "College", "Bachelor", "Master", "Doctor"]
ORDERS = {"AgeGroup": AGE_ORDER, "SalarySlab": SLAB_ORDER, "TenureBand": TENURE_ORDER, "DistanceBand": DISTANCE_ORDER,
          "EducationLevel": EDU_ORDER, "WorkLifeBalanceLabel": WLB_ORDER, "JobSatisfactionLabel": LIKERT,
          "EnvironmentSatisfactionLabel": LIKERT, "JobInvolvementLabel": LIKERT,
          "StockOptionLabel": ["None", "Level 1", "Level 2", "Level 3"],
          "JobLevel": ["1", "2", "3", "4", "5"], "NumCompaniesWorked": [str(i) for i in range(10)]}


@st.cache_data(show_spinner="Loading & cleaning data...")
def get_data():
    return load_clean()


df_all, clean_log = get_data()

# --------------------------------------------------------------------------- sidebar filters
st.sidebar.markdown("## 🎛️ Filters")
st.sidebar.caption("All tabs update instantly.")


def multi(label: str, col: str, order: list | None = None):
    opts = order if order else sorted(df_all[col].dropna().unique().tolist())
    return st.sidebar.multiselect(label, opts, default=opts)


f_dept = multi("Department", "Department")
f_role = multi("Job Role", "JobRole")
f_gender = multi("Gender", "Gender")
f_age = multi("Age Group", "AgeGroup", AGE_ORDER)
f_marital = multi("Marital Status", "MaritalStatus")
f_ot = multi("Over Time", "OverTime")
f_travel = multi("Business Travel", "BusinessTravel")
inc_lo, inc_hi = int(df_all.MonthlyIncome.min()), int(df_all.MonthlyIncome.max())
f_inc = st.sidebar.slider("Monthly income ($)", inc_lo, inc_hi, (inc_lo, inc_hi), step=100)
ten_hi = int(df_all.YearsAtCompany.max())
f_ten = st.sidebar.slider("Years at company", 0, ten_hi, (0, ten_hi))

df = df_all[
    df_all.Department.isin(f_dept) & df_all.JobRole.isin(f_role) & df_all.Gender.isin(f_gender)
    & df_all.AgeGroup.isin(f_age) & df_all.MaritalStatus.isin(f_marital) & df_all.OverTime.isin(f_ot)
    & df_all.BusinessTravel.isin(f_travel) & df_all.MonthlyIncome.between(*f_inc)
    & df_all.YearsAtCompany.between(*f_ten)
].copy()

st.sidebar.markdown("---")
st.sidebar.metric("Employees in view", f"{len(df):,}", f"{len(df) - len(df_all):,} vs total" if len(df) != len(df_all) else None)
st.sidebar.download_button("⬇️ Download filtered data (CSV)", df.to_csv(index=False).encode(), "hr_filtered.csv", "text/csv")

hero("👥 HR Analytics Dashboard", "Workforce composition, attrition drivers, compensation, satisfaction and career progression")

if df.empty:
    st.warning("No employees match the current filters. Please widen your selection in the sidebar.")
    st.stop()

tabs = st.tabs(["📊 Overview", "🚪 Attrition", "🧑‍🤝‍🧑 Workforce", "💰 Compensation",
                "😊 Satisfaction", "📈 Career & Tenure", "🔗 Correlations", "🗂️ Data & Quality"])

# =========================================================================== OVERVIEW
with tabs[0]:
    c = st.columns(6)
    left = int(df.AttritionFlag.sum())
    kpi(c[0], "Headcount", f"{len(df):,}", f"{df.Department.nunique()} departments", PRIMARY)
    kpi(c[1], "Attrition rate", f"{overall_rate(df):.1f}%", f"{left:,} employees left", LEFT)
    kpi(c[2], "Avg age", f"{df.Age.mean():.1f}", f"median {df.Age.median():.0f}", STAY)
    kpi(c[3], "Avg monthly income", f"${df.MonthlyIncome.mean():,.0f}", f"median ${df.MonthlyIncome.median():,.0f}", ACCENT)
    kpi(c[4], "Avg tenure", f"{df.YearsAtCompany.mean():.1f} yrs", f"{df.TotalWorkingYears.mean():.1f} yrs total exp.", STAY)
    kpi(c[5], "Overtime share", f"{(df.OverTime == 'Yes').mean() * 100:.0f}%", f"Avg satisfaction {df.AvgSatisfaction.mean():.2f}/4", LEFT)
    st.write("")

    a, b = st.columns([1, 1])
    with a:
        fig = px.pie(df, names="Department", hole=0.55, title="Headcount by department", color_discrete_sequence=[PRIMARY, STAY, ACCENT])
        fig.update_traces(textinfo="percent+label")
        show(fig, 350)
    with b:
        d = rate_by(df, "Department")
        fig = px.bar(d, x="Department", y="Attrition %", text="Attrition %", color="Attrition %",
                     color_continuous_scale=["#8AB17D", ACCENT, LEFT], title="Attrition rate by department",
                     hover_data=["Employees", "Left"])
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.add_hline(y=overall_rate(df), line_dash="dash", line_color=PRIMARY, annotation_text="overall")
        fig.update_coloraxes(showscale=False)
        show(fig, 350)

    st.subheader("💡 Key insights (auto-generated for the current filters)")
    ins = build_insights(df)
    ia, ib = st.columns(2)
    for i, (txt, warn) in enumerate(ins):
        with (ia if i % 2 == 0 else ib):
            insight(txt, warn)

    a, b = st.columns(2)
    with a:
        fig = px.histogram(df, x="Age", color="Attrition", nbins=30, barmode="overlay", opacity=0.75,
                           color_discrete_map=ATTR_COLORS, title="Age distribution: stayed vs left")
        show(fig, 340)
    with b:
        d = rate_by(df, "JobRole")
        fig = px.bar(d.sort_values("Attrition %"), y="JobRole", x="Attrition %", orientation="h", text="Attrition %",
                     color="Attrition %", color_continuous_scale=["#8AB17D", ACCENT, LEFT], title="Attrition rate by job role",
                     hover_data=["Employees", "Left"])
        fig.update_traces(texttemplate="%{text}%")
        fig.update_coloraxes(showscale=False)
        show(fig, 340)

# =========================================================================== ATTRITION
with tabs[1]:
    st.subheader("Where is attrition concentrated?")
    dim_label = st.selectbox("Break attrition down by:", list(CATEGORICAL_DIMS.keys()), index=1)
    col = CATEGORICAL_DIMS[dim_label]
    tmp = df.copy()
    tmp[col] = tmp[col].astype(str)
    d = rate_by(tmp, col, ORDERS.get(col))
    a, b = st.columns([3, 2])
    with a:
        fig = go.Figure()
        fig.add_bar(x=d[col], y=d["Employees"] - d["Left"], name="Stayed", marker_color=STAY)
        fig.add_bar(x=d[col], y=d["Left"], name="Left", marker_color=LEFT)
        fig.add_scatter(x=d[col], y=d["Attrition %"], name="Attrition %", yaxis="y2", mode="lines+markers+text",
                        text=d["Attrition %"].astype(str) + "%", textposition="top center",
                        line=dict(color=PRIMARY, width=3))
        fig.update_layout(barmode="stack", title=f"Headcount & attrition rate by {dim_label}",
                          yaxis2=dict(overlaying="y", side="right", showgrid=False, title="Attrition %", rangemode="tozero"),
                          yaxis_title="Employees")
        show(fig, 430)
    with b:
        show_df(d.rename(columns={col: dim_label}), hide_index=True)

    st.subheader("Hot-spot heatmap")
    h1, h2 = st.columns(2)
    xl = h1.selectbox("Rows", list(CATEGORICAL_DIMS.keys()), index=1, key="hx")
    yl = h2.selectbox("Columns", list(CATEGORICAL_DIMS.keys()), index=6, key="hy")
    xc, yc = CATEGORICAL_DIMS[xl], CATEGORICAL_DIMS[yl]
    if xc == yc:
        st.info("Pick two different dimensions.")
    else:
        t = df.assign(**{xc: df[xc].astype(str), yc: df[yc].astype(str)})
        piv = t.pivot_table(index=xc, columns=yc, values="AttritionFlag", aggfunc="mean") * 100
        cnt = t.pivot_table(index=xc, columns=yc, values="AttritionFlag", aggfunc="count")
        fig = px.imshow(piv.round(1), text_auto=".1f", aspect="auto", color_continuous_scale=["#e8f5f2", ACCENT, LEFT],
                        labels=dict(color="Attrition %"), title=f"Attrition % - {xl} x {yl}")
        fig.update_traces(customdata=cnt.values, hovertemplate="%{y} / %{x}<br>Attrition: %{z:.1f}%<br>n=%{customdata}<extra></extra>")
        show(fig, 460)
        st.caption("Small cells (low n) can be volatile - hover to see headcount.")

    st.subheader("Do leavers differ numerically?")
    num = st.selectbox("Metric", [c for c in NUMERIC_COLS if c != "Education"], index=NUMERIC_COLS.index("MonthlyIncome"))
    a, b = st.columns(2)
    with a:
        show(px.box(df, x="Attrition", y=num, color="Attrition", color_discrete_map=ATTR_COLORS, points="outliers",
                    title=f"{num}: stayed vs left"), 380)
    with b:
        show(px.violin(df, x="Attrition", y=num, color="Attrition", color_discrete_map=ATTR_COLORS, box=True,
                       title=f"{num}: distribution shape"), 380)

# =========================================================================== WORKFORCE
with tabs[2]:
    a, b = st.columns(2)
    with a:
        sb = df.groupby(["Department", "JobRole"]).size().reset_index(name="Employees")
        show(px.sunburst(sb, path=["Department", "JobRole"], values="Employees", title="Department → Job role",
                         color_discrete_sequence=px.colors.qualitative.Safe), 480)
    with b:
        g = df.groupby(["Department", "Gender"]).size().reset_index(name="Employees")
        show(px.bar(g, x="Department", y="Employees", color="Gender", barmode="group", text="Employees",
                    color_discrete_map={"Male": PRIMARY, "Female": LEFT}, title="Gender mix by department"), 480)
    a, b, c = st.columns(3)
    with a:
        g = df.groupby("MaritalStatus").size().reset_index(name="n")
        show(px.pie(g, names="MaritalStatus", values="n", hole=0.5, title="Marital status"), 330)
    with b:
        g = df.groupby("EducationLevel").size().reindex(EDU_ORDER).dropna().reset_index(name="n")
        show(px.bar(g, x="EducationLevel", y="n", title="Education level", color_discrete_sequence=[STAY]), 330)
    with c:
        g = df.groupby("BusinessTravel").size().reset_index(name="n")
        show(px.pie(g, names="BusinessTravel", values="n", hole=0.5, title="Business travel"), 330)
    a, b = st.columns(2)
    with a:
        g = df.groupby("EducationField").size().sort_values().reset_index(name="n")
        show(px.bar(g, y="EducationField", x="n", orientation="h", title="Education field", color_discrete_sequence=[PRIMARY]), 360)
    with b:
        g = df.groupby(["AgeGroup", "Gender"]).size().reset_index(name="n")
        g["AgeGroup"] = pd.Categorical(g["AgeGroup"], AGE_ORDER, ordered=True)
        show(px.bar(g.sort_values("AgeGroup"), x="AgeGroup", y="n", color="Gender", barmode="stack",
                    color_discrete_map={"Male": PRIMARY, "Female": LEFT}, title="Age pyramid (by group)"), 360)
    st.subheader("Distance from home")
    show(px.histogram(df, x="DistanceFromHome", color="Attrition", nbins=29, barmode="stack",
                      color_discrete_map=ATTR_COLORS, title="Commute distance (km) - stayed vs left"), 340)

# =========================================================================== COMPENSATION
with tabs[3]:
    c = st.columns(4)
    kpi(c[0], "Avg monthly income", f"${df.MonthlyIncome.mean():,.0f}", "", PRIMARY)
    kpi(c[1], "Avg hourly rate", f"${df.HourlyRate.mean():,.1f}", "", STAY)
    kpi(c[2], "Avg salary hike", f"{df.PercentSalaryHike.mean():.1f}%", "", ACCENT)
    gm = df.groupby("Gender").MonthlyIncome.mean()
    gap = (gm.get("Female", 0) / gm.get("Male", 1) - 1) * 100 if {"Male", "Female"} <= set(gm.index) else float("nan")
    kpi(c[3], "Female vs male avg pay", f"{gap:+.1f}%" if gap == gap else "n/a", "unadjusted for role / level", LEFT)
    st.write("")
    a, b = st.columns(2)
    with a:
        d = rate_by(df, "SalarySlab", SLAB_ORDER)
        fig = px.bar(d, x="SalarySlab", y="Attrition %", text="Attrition %", title="Attrition by salary slab",
                     color="Attrition %", color_continuous_scale=["#8AB17D", ACCENT, LEFT], hover_data=["Employees"])
        fig.update_traces(texttemplate="%{text}%")
        fig.update_coloraxes(showscale=False)
        show(fig, 380)
    with b:
        show(px.box(df.assign(JobLevel=df.JobLevel.astype(str)).sort_values("JobLevel"), x="JobLevel", y="MonthlyIncome",
                    color="Attrition", color_discrete_map=ATTR_COLORS, title="Monthly income by job level"), 380)
    a, b = st.columns(2)
    with a:
        g = df.groupby("JobRole").MonthlyIncome.mean().sort_values().reset_index()
        show(px.bar(g, y="JobRole", x="MonthlyIncome", orientation="h", title="Average income by job role",
                    color_discrete_sequence=[PRIMARY]), 400)
    with b:
        g = df.groupby(["JobLevel", "Gender"]).MonthlyIncome.mean().reset_index()
        show(px.bar(g, x="JobLevel", y="MonthlyIncome", color="Gender", barmode="group",
                    color_discrete_map={"Male": PRIMARY, "Female": LEFT}, title="Average income: gender × job level"), 400)
    st.subheader("Income vs experience")
    fig = px.scatter(df, x="TotalWorkingYears", y="MonthlyIncome", color="Attrition", symbol="Attrition", opacity=0.65,
                     color_discrete_map=ATTR_COLORS, hover_data=["EmpID", "JobRole", "Department"],
                     title="Monthly income vs total working years")
    show(fig, 440)
    a, b = st.columns(2)
    with a:
        g = df.groupby("PerformanceLabel").agg(Hike=("PercentSalaryHike", "mean"), n=("EmpID", "count")).reset_index()
        show(px.bar(g, x="PerformanceLabel", y="Hike", text=g["Hike"].round(1), title="Avg salary hike % by performance rating",
                    color_discrete_sequence=[STAY]), 340)
    with b:
        d = rate_by(df, "StockOptionLabel", ORDERS["StockOptionLabel"])
        fig = px.bar(d, x="StockOptionLabel", y="Attrition %", text="Attrition %", title="Attrition by stock option level",
                     color_discrete_sequence=[LEFT])
        fig.update_traces(texttemplate="%{text}%")
        show(fig, 340)

# =========================================================================== SATISFACTION
with tabs[4]:
    sat_cols = {"Environment": "EnvironmentSatisfaction", "Job": "JobSatisfaction",
                "Relationship": "RelationshipSatisfaction", "Work-life balance": "WorkLifeBalance",
                "Job involvement": "JobInvolvement"}
    c = st.columns(5)
    for i, (k, v) in enumerate(sat_cols.items()):
        kpi(c[i], f"{k}", f"{df[v].mean():.2f} / 4", f"leavers {df[df.Attrition == 'Yes'][v].mean():.2f}" if left else "", [STAY, PRIMARY, ACCENT, LEFT, STAY][i])
    st.write("")
    a, b = st.columns(2)
    with a:
        by = st.selectbox("Heatmap grouped by", ["JobRole", "Department", "AgeGroup", "OverTime", "MaritalStatus"], key="sat_by")
        m = df.groupby(by)[list(sat_cols.values())].mean().round(2)
        m.columns = list(sat_cols.keys())
        fig = px.imshow(m, text_auto=".2f", aspect="auto", color_continuous_scale="RdYlGn", zmin=1.5, zmax=3.5,
                        title=f"Average scores by {by}")
        show(fig, 430)
    with b:
        which = st.selectbox("Attrition by score of:", list(sat_cols.keys()), key="sat_att")
        c_ = sat_cols[which]
        d = rate_by(df.assign(**{c_: df[c_].astype(str)}), c_, ["1", "2", "3", "4"])
        fig = px.bar(d, x=c_, y="Attrition %", text="Attrition %", color="Attrition %", hover_data=["Employees"],
                     color_continuous_scale=["#8AB17D", ACCENT, LEFT], title=f"Attrition by {which.lower()} score (1=low, 4=high)")
        fig.update_traces(texttemplate="%{text}%")
        fig.update_coloraxes(showscale=False)
        show(fig, 430)
    a, b = st.columns(2)
    with a:
        g = df.groupby(["JobSatisfactionLabel", "Attrition"]).size().reset_index(name="n")
        show(px.bar(g, x="JobSatisfactionLabel", y="n", color="Attrition", barmode="relative", barnorm="percent",
                    category_orders={"JobSatisfactionLabel": LIKERT}, color_discrete_map=ATTR_COLORS,
                    title="Job satisfaction - share stayed vs left (%)"), 360)
    with b:
        g = df.groupby(["WorkLifeBalanceLabel", "OverTime"]).size().reset_index(name="n")
        show(px.bar(g, x="WorkLifeBalanceLabel", y="n", color="OverTime", barmode="group",
                    category_orders={"WorkLifeBalanceLabel": WLB_ORDER}, color_discrete_map={"Yes": LEFT, "No": STAY},
                    title="Work-life balance vs overtime"), 360)
    g = df.groupby(["PerformanceLabel", "JobSatisfactionLabel"]).size().reset_index(name="n")
    show(px.bar(g, x="PerformanceLabel", y="n", color="JobSatisfactionLabel", barmode="stack",
                category_orders={"JobSatisfactionLabel": LIKERT},
                color_discrete_sequence=[LEFT, ACCENT, "#8AB17D", STAY], title="Performance rating × job satisfaction"), 340)

# =========================================================================== CAREER
with tabs[5]:
    c = st.columns(4)
    kpi(c[0], "Avg years at company", f"{df.YearsAtCompany.mean():.1f}", "", PRIMARY)
    kpi(c[1], "Avg years in role", f"{df.YearsInCurrentRole.mean():.1f}", "", STAY)
    kpi(c[2], "Avg yrs since promotion", f"{df.YearsSinceLastPromotion.mean():.1f}", "", ACCENT)
    kpi(c[3], "No promotion 5+ yrs", f"{(df.YearsSinceLastPromotion >= 5).mean() * 100:.0f}%", "of employees", LEFT)
    st.write("")
    a, b = st.columns(2)
    with a:
        d = rate_by(df, "TenureBand", TENURE_ORDER)
        fig = px.bar(d, x="TenureBand", y="Attrition %", text="Attrition %", color="Attrition %", hover_data=["Employees"],
                     color_continuous_scale=["#8AB17D", ACCENT, LEFT], title="Attrition by tenure band")
        fig.update_traces(texttemplate="%{text}%")
        fig.update_coloraxes(showscale=False)
        show(fig, 360)
    with b:
        show(px.histogram(df, x="YearsSinceLastPromotion", color="Attrition", barmode="overlay", opacity=0.75,
                          color_discrete_map=ATTR_COLORS, title="Years since last promotion"), 360)
    a, b = st.columns(2)
    with a:
        g = df.groupby("YearsAtCompany").AttritionFlag.agg(["mean", "count"]).reset_index()
        g = g[g["count"] >= 5]
        fig = px.line(g, x="YearsAtCompany", y=g["mean"] * 100, markers=True, title="Attrition % by exact years at company (n ≥ 5)",
                      labels={"y": "Attrition %"}, color_discrete_sequence=[LEFT])
        show(fig, 360)
    with b:
        d = rate_by(df.assign(NumCompaniesWorked=df.NumCompaniesWorked.astype(str)), "NumCompaniesWorked", ORDERS["NumCompaniesWorked"])
        fig = px.bar(d, x="NumCompaniesWorked", y="Attrition %", text="Attrition %", title="Attrition by # of previous companies",
                     color_discrete_sequence=[PRIMARY], hover_data=["Employees"])
        fig.update_traces(texttemplate="%{text}%")
        show(fig, 360)
    fig = px.scatter(df, x="YearsAtCompany", y="YearsInCurrentRole", color="JobRole", size="MonthlyIncome", opacity=0.6,
                     hover_data=["EmpID", "Attrition"], title="Company tenure vs time in current role (bubble = income)")
    show(fig, 460)
    a, b = st.columns(2)
    with a:
        g = df.groupby("TrainingTimesLastYear").AttritionFlag.agg(["mean", "count"]).reset_index()
        fig = px.bar(g, x="TrainingTimesLastYear", y=g["mean"] * 100, hover_data=["count"], labels={"y": "Attrition %"},
                     title="Attrition by training sessions last year", color_discrete_sequence=[STAY])
        show(fig, 330)
    with b:
        g = df.groupby("JobLevel")[["YearsAtCompany", "YearsInCurrentRole", "YearsSinceLastPromotion"]].mean().round(1).reset_index()
        g = g.melt("JobLevel", var_name="Metric", value_name="Years")
        show(px.bar(g, x="JobLevel", y="Years", color="Metric", barmode="group", title="Average tenure metrics by job level"), 330)

# =========================================================================== CORRELATIONS
with tabs[6]:
    a, b = st.columns([3, 2])
    with a:
        default = ["Age", "MonthlyIncome", "JobLevel", "TotalWorkingYears", "YearsAtCompany", "YearsInCurrentRole",
                   "YearsSinceLastPromotion", "YearsWithCurrManager", "JobSatisfaction", "WorkLifeBalance",
                   "DistanceFromHome", "PercentSalaryHike", "AttritionFlag"]
        sel = st.multiselect("Variables", NUMERIC_COLS + ["AttritionFlag"], default=default)
        if len(sel) >= 2:
            fig = px.imshow(correlations(df, sel), text_auto=".2f", aspect="auto", zmin=-1, zmax=1,
                            color_continuous_scale="RdBu_r", title="Pearson correlation matrix")
            show(fig, 620)
        else:
            st.info("Select at least two variables.")
    with b:
        ac = attrition_correlations(df).rename("Correlation").rename_axis("Variable").reset_index()
        fig = px.bar(ac, x="Correlation", y="Variable", orientation="h",
                     title="Correlation with attrition", color="Correlation", color_continuous_scale="RdBu_r",
                     range_color=[-0.3, 0.3])
        fig.update_coloraxes(showscale=False)
        show(fig, 620)
    st.caption("Correlation ≠ causation. Strong tenure/level/income inter-correlations reflect that these measures grow together with age and seniority.")

# =========================================================================== DATA & QUALITY
with tabs[7]:
    st.subheader("🧹 Cleaning report")
    c = st.columns(4)
    raw_rows = int(clean_log[-1]["Rows / cells affected"]) + len(df_all)
    kpi(c[0], "Raw rows", f"{raw_rows:,}", "HR_Analytics sheet", PRIMARY)
    kpi(c[1], "Clean rows", f"{len(df_all):,}", "unique employees", STAY)
    kpi(c[2], "Columns after cleaning", f"{df_all.shape[1]}", "incl. engineered features", ACCENT)
    kpi(c[3], "Missing values left", f"{int(df_all.isna().sum().sum())}", "after imputation", LEFT)
    st.write("")
    show_df(pd.DataFrame(clean_log), hide_index=True)
    st.markdown("**Note:** the workbook's `Detail1` and `Sheet1` tabs are pivot-table by-products (a single drill-down row and a "
                "distance-per-employee pivot) and were not used.")

    st.subheader("🔍 Data explorer")
    cols = st.multiselect("Columns to show", df.columns.tolist(),
                          default=["EmpID", "Age", "Department", "JobRole", "Gender", "MonthlyIncome", "OverTime",
                                   "YearsAtCompany", "AvgSatisfaction", "Attrition"])
    q = st.text_input("Search EmpID / JobRole contains:")
    view = df
    if q:
        view = df[df.EmpID.str.contains(q, case=False, na=False) | df.JobRole.str.contains(q, case=False, na=False)]
    show_df(view[cols] if cols else view, hide_index=True)
    d1, d2 = st.columns(2)
    d1.download_button("⬇️ Cleaned dataset (CSV)", df_all.to_csv(index=False).encode(), "HR_Analytics_cleaned.csv", "text/csv")
    d2.download_button("⬇️ Cleaning log (CSV)", pd.DataFrame(clean_log).to_csv(index=False).encode(), "cleaning_log.csv", "text/csv")

    st.subheader("📐 Summary statistics (filtered)")
    show_df(df[NUMERIC_COLS].describe().T.round(2))
