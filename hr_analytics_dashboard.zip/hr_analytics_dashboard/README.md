# 👥 HR Analytics Dashboard (Streamlit)

An interactive, cleaned and presentation-ready analysis of the `HR_Analytics.xlsx` workforce dataset.

## Quick start

```bash
# macOS / Linux              # Windows
./run.sh                     run.bat
```
or manually:
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
The app opens at http://localhost:8501. Python 3.10+ recommended.

## What's inside

| Tab | Contents |
|---|---|
| 📊 Overview | 6 KPI cards, headcount/attrition by department & role, **auto-generated insights** |
| 🚪 Attrition | Break attrition down by 19 dimensions, 2-way hot-spot heatmap, leaver vs stayer distributions |
| 🧑‍🤝‍🧑 Workforce | Dept→role sunburst, gender mix, education, marital, travel, commute |
| 💰 Compensation | Salary slab, income by level/role/gender, income vs experience, hikes, stock options |
| 😊 Satisfaction | Score heatmaps, attrition by score, WLB vs overtime |
| 📈 Career & Tenure | Tenure bands, promotion gap, prior employers, training |
| 🔗 Correlations | Selectable correlation matrix + correlation with attrition |
| 🗂️ Data & Quality | Full cleaning log, searchable data explorer, CSV downloads |

The **sidebar filters** (department, role, gender, age group, marital status, overtime, travel, income, tenure) drive every tab.

## Data cleaning performed (see the in-app report)

| Issue | Action |
|---|---|
| Workbook has 3 sheets; `Detail1`, `Sheet1` are pivot-table leftovers | Only `HR_Analytics` used |
| 7 fully duplicated rows | Removed |
| 3 EmpIDs repeated with conflicting `YearsWithCurrManager` | Kept first occurrence |
| `TravelRarely` vs `Travel_Rarely` (8 rows) | Standardised |
| 57 blank `YearsWithCurrManager` | Imputed with JobRole median, capped at YearsAtCompany, flagged in `ManagerYearsImputed` |
| Constant columns (`EmployeeCount`, `StandardHours`, `Over18`) | Dropped |
| Numeric codes (1–4 scales) | Added readable labels |
| New features | `AttritionFlag`, `TenureBand`, `DistanceBand`, `AvgSatisfaction`, `IncomePerYearOfExp` |

Result: **1,480 → 1,470 rows**, zero missing values, no tenure inconsistencies.

## Project layout
```
app.py                  Streamlit dashboard
utils/cleaning.py       load + clean + feature engineering (+ cleaning log)
utils/analysis.py       pure-pandas helpers & auto-insights
utils/ui.py             theme, CSS, KPI cards
data/HR_Analytics.xlsx  original data
data/HR_Analytics_cleaned.csv   cleaned output (regenerate: python -m utils.cleaning)
tests/                  pytest checks   (pip install -r requirements-dev.txt; pytest)
.streamlit/config.toml  theme
```

## Notes
- Findings are associations, not causal claims.
- To use another file, replace `data/HR_Analytics.xlsx` (same columns) and restart.
