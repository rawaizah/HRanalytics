#!/bin/bash
# Generate brand imagery for Aura Events & Consulting website
# Style: consistent professional event photography, violet/amber grade, no readable text
RAW=/home/z/my-project/scripts/img_raw
mkdir -p "$RAW"

z-ai image -p "Wide shot of an elegant corporate gala event in a grand banquet hall, dramatic violet purple and warm gold stage lighting, large LED screen backdrop glowing, round banquet tables with candles and glassware, subtle light haze, professional event photography, cinematic, high quality, detailed, no people in focus, no readable text" -o "$RAW/hero-gala.png" -s 1440x720 &

z-ai image -p "Modern business conference stage, panel of speakers silhouetted against a large deep purple LED backdrop, audience seen from behind in a dark auditorium, violet and amber spotlights, professional event photography, cinematic, high quality, detailed, no readable text" -o "$RAW/work-summit.png" -s 1344x768 &

z-ai image -p "Modern exhibition trade show booth with violet purple and gold branded panels, sleek product display counters, bright spotlights, minimalist premium design, wide angle professional photography, high quality, detailed, no people in focus, no readable text" -o "$RAW/work-expo.png" -s 1344x768 &

z-ai image -p "Luxury wedding reception venue at dusk, warm string lights overhead, elegant floral centerpieces in white and gold, glass table settings with candles, romantic ambient golden lighting, professional event photography, high quality, detailed, no people, no readable text" -o "$RAW/work-wedding.png" -s 1344x768 &

z-ai image -p "Professional live streaming studio set up for a hybrid corporate event, broadcast cameras on tripods, lighting rig, modern presenter desk with monitors, violet purple accent lighting in dark studio, professional photography, high quality, detailed, no people in focus, no readable text" -o "$RAW/work-hybrid.png" -s 1344x768 &

wait
echo "---- generated files ----"
ls -la "$RAW"
