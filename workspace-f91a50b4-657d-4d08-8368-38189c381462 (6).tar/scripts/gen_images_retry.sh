#!/bin/bash
RAW=/home/z/my-project/scripts/img_raw
mkdir -p "$RAW"

gen() {
  local prompt="$1" out="$2" size="$3"
  for i in 1 2 3; do
    if z-ai image -p "$prompt" -o "$out" -s "$size" 2>/dev/null; then
      echo "OK: $out"; return 0
    fi
    echo "retry $i failed for $out"; sleep 4
  done
  echo "FAIL: $out"; return 1
}

gen "Wide shot of an elegant corporate gala event in a grand banquet hall, dramatic violet purple and warm gold stage lighting, large LED screen backdrop glowing, round banquet tables with candles and glassware, subtle light haze, professional event photography, cinematic, high quality, detailed, no people in focus, no readable text" "$RAW/hero-gala.png" "1408x768" &

gen "Modern business conference stage, panel of speakers silhouetted against a large deep purple LED backdrop, audience seen from behind in a dark auditorium, violet and amber spotlights, professional event photography, cinematic, high quality, detailed, no readable text" "$RAW/work-summit.png" "1344x768" &

wait

gen "Modern exhibition trade show booth with violet purple and gold branded panels, sleek product display counters, bright spotlights, minimalist premium design, wide angle professional photography, high quality, detailed, no people in focus, no readable text" "$RAW/work-expo.png" "1344x768" &

gen "Professional live streaming studio set up for a hybrid corporate event, broadcast cameras on tripods, lighting rig, modern presenter desk with monitors, violet purple accent lighting in dark studio, professional photography, high quality, detailed, no people in focus, no readable text" "$RAW/work-hybrid.png" "1344x768" &

wait
echo "---- generated files ----"
ls -la "$RAW"
