#!/usr/bin/env python3
"""Optimize generated PNGs -> web JPEGs for the Aura website assets folder."""
import os
from PIL import Image

RAW = "/home/z/my-project/scripts/img_raw"
OUT = "/home/z/my-project/download/aura-events-website/assets/img"
os.makedirs(OUT, exist_ok=True)

# (source, dest, target_width, quality)
JOBS = [
    ("hero-gala.png",   "hero-gala.jpg",   1280, 84),
    ("work-summit.png", "work-summit.jpg", 1100, 82),
    ("work-expo.png",   "work-expo.jpg",   1100, 82),
    ("work-wedding.png","work-wedding.jpg",1100, 82),
    ("work-hybrid.png", "work-hybrid.jpg", 1100, 82),
]

total = 0
for src, dst, w, q in JOBS:
    im = Image.open(os.path.join(RAW, src)).convert("RGB")
    if im.width > w:
        h = round(im.height * w / im.width)
        im = im.resize((w, h), Image.LANCZOS)
    path = os.path.join(OUT, dst)
    im.save(path, "JPEG", quality=q, optimize=True, progressive=True)
    kb = os.path.getsize(path) / 1024
    total += kb
    print(f"{dst:22s} {im.width}x{im.height}  {kb:7.1f} KB")
print(f"TOTAL: {total/1024:.2f} MB")
